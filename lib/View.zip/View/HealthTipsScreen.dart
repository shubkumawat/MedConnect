import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:digitalhealth/app/core/Util/AdditionalWidget/AdditionalWidget.dart';
import 'package:digitalhealth/app/core/theme/app_colors.dart';
import 'package:digitalhealth/app/core/theme/app_text_theme.dart';
import 'package:digitalhealth/app/core/Util/CustomButton/CustomButton.dart';
import 'package:digitalhealth/app/core/Util/CustomTextField/CustomTextField.dart';

class HealthTipsScreen extends StatefulWidget {
  const HealthTipsScreen({super.key});

  @override
  State<HealthTipsScreen> createState() => _HealthTipsScreenState();
}

class _HealthTipsScreenState extends State<HealthTipsScreen> {
  int _selectedCat = 0;

  final _categories = [
    {'label': 'All', 'icon': Icons.grid_view_rounded},
    {'label': 'Nutrition', 'icon': Icons.restaurant_menu},
    {'label': 'Fitness', 'icon': Icons.fitness_center},
    {'label': 'Mental', 'icon': Icons.psychology_outlined},
    {'label': 'Preventive', 'icon': Icons.shield_outlined},
  ];

  final _tips = [
    {
      'cat': 'Nutrition',
      'emoji': '🥗',
      'title': 'Drink More Water',
      'body': 'Drink 8 glasses of water daily to maintain energy levels and support kidney health. Dehydration can cause fatigue and headaches.',
      'color': AppColors.green,
      'helpful': 234,
      'isHelpful': false,
    },
    {
      'cat': 'Fitness',
      'emoji': '🏃',
      'title': 'Daily Walking',
      'body': '30 minutes of brisk walking daily reduces blood pressure, improves heart health, and boosts metabolism significantly.',
      'color': AppColors.orange,
      'helpful': 456,
      'isHelpful': true,
    },
    {
      'cat': 'Mental',
      'emoji': '🧠',
      'title': 'Deep Breathing Before Bed',
      'body': '5 minutes of deep breathing exercises before bed improves sleep quality and reduces cortisol levels by up to 23%.',
      'color': AppColors.accentBlue,
      'helpful': 189,
      'isHelpful': false,
    },
    {
      'cat': 'Preventive',
      'emoji': '🛡️',
      'title': 'Annual Health Checkup',
      'body': 'Schedule a comprehensive annual checkup even when feeling healthy. Early detection saves lives — blood pressure, sugar, and cholesterol.',
      'color': AppColors.teal,
      'helpful': 312,
      'isHelpful': false,
    },
    {
      'cat': 'Nutrition',
      'emoji': '🥦',
      'title': 'Eat More Greens',
      'body': 'Include at least 3 servings of leafy vegetables per day. Spinach, fenugreek, and broccoli are packed with iron and folate.',
      'color': AppColors.green,
      'helpful': 156,
      'isHelpful': false,
    },
    {
      'cat': 'Mental',
      'emoji': '🧘',
      'title': 'Practice Mindfulness',
      'body': '10 minutes of daily mindfulness meditation reduces anxiety by 60% and improves focus and emotional regulation.',
      'color': AppColors.accentBlue,
      'helpful': 278,
      'isHelpful': true,
    },
  ];

  List<Map<String, dynamic>> get _filteredTips {
    if (_selectedCat == 0) return _tips;
    final cat = _categories[_selectedCat]['label'] as String;
    return _tips.where((t) => t['cat'] == cat).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgNavy,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          // ── Premium Immersive Header ──────────────────────────────────────
          SliverAppBar(
            expandedHeight: 200.0,
            pinned: true,
            elevation: 0,
            backgroundColor: AppColors.bgNavy,
            automaticallyImplyLeading: false,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
              onPressed: () => Navigator.pop(context),
            ),
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Container(color: AppColors.teal),
                  Positioned(
                    right: -20,
                    top: -20,
                    child: Icon(Icons.tips_and_updates_rounded, size: 180, color: Colors.white.withOpacity(0.05)),
                  ),
                  Positioned(
                    bottom: 60,
                    left: 20,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('Wellness', style: AppTextStyles.heading2.copyWith(color: Colors.white.withOpacity(0.6), fontSize: 24)),
                        Text('Health Library', style: AppTextStyles.heading1.copyWith(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900)),
                      ],
                    ),
                  ),
                  // Bottom Curve
                  Positioned(
                    bottom: -1,
                    left: 0,
                    right: 0,
                    child: Container(
                      height: 30,
                      decoration: BoxDecoration(
                        color: AppColors.bgNavy,
                        borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // ── Sticky Category Filters ───────────────────────────────────────
          SliverPersistentHeader(
            pinned: true,
            delegate: _StickyCategoryDelegate(
              child: Container(
                color: AppColors.bgNavy,
                padding: const EdgeInsets.symmetric(vertical: 12),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Row(
                    children: List.generate(_categories.length, (i) {
                      final cat = _categories[i];
                      final sel = _selectedCat == i;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedCat = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          margin: const EdgeInsets.only(right: 10),
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                          decoration: BoxDecoration(
                            color: sel ? AppColors.teal : AppColors.bgCardNavy,
                            borderRadius: BorderRadius.circular(30),
                            border: Border.all(color: sel ? AppColors.teal : AppColors.border.withOpacity(0.3)),
                            boxShadow: sel ? [BoxShadow(color: AppColors.teal.withOpacity(0.2), blurRadius: 8, offset: const Offset(0, 4))] : null,
                          ),
                          child: Row(
                            children: [
                              Icon(
                                cat['icon'] as IconData,
                                size: 16,
                                color: sel ? Colors.white : AppColors.textMuted,
                              ),
                              const SizedBox(width: 8),
                              Text(
                                cat['label'] as String,
                                style: AppTextStyles.captionBold.copyWith(
                                  color: sel ? Colors.white : AppColors.textMuted,
                                  fontSize: 13,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    }),
                  ),
                ),
              ),
            ),
          ),

          // ── Tips List ───────────────────────────────────────────────────
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 40),
            sliver: _filteredTips.isEmpty
                ? const SliverFillRemaining(
                    child: Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.tips_and_updates_outlined, color: AppColors.textMuted, size: 56),
                          SizedBox(height: 16),
                          Text('No tips in this category yet', style: TextStyle(color: AppColors.textMuted)),
                        ],
                      ),
                    ),
                  )
                : SliverList(
                    delegate: SliverChildBuilderDelegate(
                      (_, i) {
                        final tip = _filteredTips[i];
                        return _TipCard(
                          tip: tip,
                          onHelpful: () {
                            setState(() => tip['isHelpful'] = !(tip['isHelpful'] as bool));
                          },
                        );
                      },
                      childCount: _filteredTips.length,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _StickyCategoryDelegate extends SliverPersistentHeaderDelegate {
  final Widget child;
  _StickyCategoryDelegate({required this.child});
  @override Widget build(context, shrinkOffset, overlapsContent) => child;
  @override double get maxExtent => 64;
  @override double get minExtent => 64;
  @override bool shouldRebuild(covariant SliverPersistentHeaderDelegate oldDelegate) => true;
}

class _TipCard extends StatelessWidget {
  final Map<String, dynamic> tip;
  final VoidCallback onHelpful;
  const _TipCard({required this.tip, required this.onHelpful});

  @override
  Widget build(BuildContext context) {
    final themeColor = tip['color'] as Color;
    final isHelpful = tip['isHelpful'] as bool;

    return Container(
      margin: const EdgeInsets.only(bottom: 20),
      decoration: BoxDecoration(
        color: AppColors.bgCardNavy,
        borderRadius: BorderRadius.circular(24),
        // Premium Accent Border (4px top and left)
        border: Border(
          left: BorderSide(color: themeColor, width: 4),
          top: BorderSide(color: themeColor, width: 4),
          right: BorderSide(color: AppColors.border.withOpacity(0.3), width: 1),
          bottom: BorderSide(color: AppColors.border.withOpacity(0.3), width: 1),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 15,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: themeColor.withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Text(tip['emoji'] as String, style: const TextStyle(fontSize: 24)),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                          color: themeColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          (tip['cat'] as String).toUpperCase(),
                          style: TextStyle(color: themeColor, fontSize: 10, fontWeight: FontWeight.w800, letterSpacing: 0.5),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(tip['title'] as String, style: AppTextStyles.heading3.copyWith(fontSize: 18, color: AppColors.primary)),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Body text
          Padding(
            padding: const EdgeInsets.all(20),
            child: Text(
              tip['body'] as String,
              style: AppTextStyles.body.copyWith(color: AppColors.textMuted, height: 1.5, fontSize: 15),
            ),
          ),

          // Actions
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
            decoration: BoxDecoration(
              border: Border(top: BorderSide(color: AppColors.border.withOpacity(0.3))),
            ),
            child: Row(
              children: [
                GestureDetector(
                  onTap: onHelpful,
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      color: isHelpful ? themeColor.withOpacity(0.1) : Colors.transparent,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          isHelpful ? Icons.thumb_up : Icons.thumb_up_outlined,
                          color: isHelpful ? themeColor : AppColors.textMuted,
                          size: 18,
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${tip['helpful']} Helpful',
                          style: AppTextStyles.captionBold.copyWith(
                            color: isHelpful ? themeColor : AppColors.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const Spacer(),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.share_outlined, color: AppColors.textMuted, size: 20),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
                const SizedBox(width: 15),
                IconButton(
                  onPressed: () {},
                  icon: const Icon(Icons.bookmark_border_rounded, color: AppColors.textMuted, size: 22),
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
