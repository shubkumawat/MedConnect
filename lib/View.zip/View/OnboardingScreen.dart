import 'package:flutter/material.dart';

import 'package:digitalhealth/app/core//Util/CustomButton/CustomButton.dart';
import '../app/core/theme/app_colors.dart';
import '../app/core/theme/app_text_theme.dart';
import '../app/modules/login/views/login_view.dart';


class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final PageController _pageController = PageController();
  int _currentPage = 0;

  final List<_OnboardData> _pages = [
    _OnboardData(
      icon: Icons.family_restroom,
      color: AppColors.primary,
      title: 'One App for Your\nWhole Family\'s Health',
      subtitle: 'Manage health records for every family member — each as a full patient.',
    ),
    _OnboardData(
      icon: Icons.qr_code_scanner,
      color: AppColors.teal,
      title: 'Share Instantly\nwith Your Doctor',
      subtitle: 'Show your QR code to any doctor — no app needed on their side.',
    ),
    _OnboardData(
      icon: Icons.notifications_active,
      color: AppColors.primary,
      title: 'Never Miss a Dose\nor Vaccination',
      subtitle: 'Smart reminders for medicines, vaccines, and follow-up appointments.',
    ),
  ];

  void _goToLogin() {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const LoginScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgNavy,
      body: SafeArea(
        child: Column(
          children: [
            // Skip button
            Align(
              alignment: Alignment.topRight,
              child: GestureDetector(
                onTap: _goToLogin,
                child: Padding(
                  padding: const EdgeInsets.all(20),
                  child: Text('Skip', style: AppTextStyles.tealLabel.copyWith(fontSize: 14)),
                ),
              ),
            ),

            // Page View
            Expanded(
              child: PageView.builder(
                controller: _pageController,
                onPageChanged: (i) => setState(() => _currentPage = i),
                itemCount: _pages.length,
                itemBuilder: (_, i) => _OnboardPage(data: _pages[i]),
              ),
            ),

            // Dots
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(_pages.length, (i) {
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  width: _currentPage == i ? 24 : 8,
                  height: 8,
                  decoration: BoxDecoration(
                    color: _currentPage == i
                        ? _pages[_currentPage].color
                        : AppColors.border,
                    borderRadius: BorderRadius.circular(4),
                  ),
                );
              }),
            ),

            const SizedBox(height: 32),

            // Button
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 24),
              child: CustomPrimaryButton(
                text: _currentPage == _pages.length - 1 ? 'Get Started' : 'Next →',
                color: _pages[_currentPage].color,
                onTap: () {
                  if (_currentPage < _pages.length - 1) {
                    _pageController.nextPage(
                      duration: const Duration(milliseconds: 350),
                      curve: Curves.easeInOut,
                    );
                  } else {
                    _goToLogin();
                  }
                },
              ),
            ),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }
}

class _OnboardPage extends StatelessWidget {
  final _OnboardData data;
  const _OnboardPage({required this.data});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Illustration circle
          Container(
            width: 160,
            height: 160,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: data.color.withOpacity(0.15),
              border: Border.all(color: data.color.withOpacity(0.3), width: 2),
            ),
            child: Icon(data.icon, color: data.color, size: 72),
          ),
          const SizedBox(height: 48),

          Text(
            data.title,
            style: AppTextStyles.heading1.copyWith(fontSize: 24),
            textAlign: TextAlign.center,

          ),
          const SizedBox(height: 16),

          Text(
            data.subtitle,
            style: AppTextStyles.body,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _OnboardData {
  final IconData icon;
  final Color color;
  final String title;
  final String subtitle;
  const _OnboardData({
    required this.icon,
    required this.color,
    required this.title,
    required this.subtitle,
  });
}