import 'package:digitalhealth/View/AddMedicationScreen.dart';
import 'package:flutter/material.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get/get_navigation/src/extension_navigation.dart';
import 'package:digitalhealth/app/core//Util/AdditionalWidget/AdditionalWidget.dart';
import 'package:digitalhealth/app/core//Util/Colors/colors.dart';
import 'package:digitalhealth/app/core//Util/CustomButton/CustomButton.dart';
import 'package:digitalhealth/app/core//Util/CustomCardWidgets/CustomCardWidgets.dart';
import 'package:digitalhealth/app/core//Util/Font/font_family.dart';
import '../../app/modules/records/views/add_disease_screen.dart';
import '../../app/modules/records/views/ai_prescription_screen.dart';
import '../../app/modules/records/views/disease_detail_screen.dart';


class RecordsScreen extends StatefulWidget {
  const RecordsScreen({super.key});
  @override
  State<RecordsScreen> createState() => _RecordsScreenState();
}

class _RecordsScreenState extends State<RecordsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _timelineFilter = 0;

  final _diseases = [
    {'name': 'Hernia (Inguinal)', 'status': 'Active', 'diagnosed': 'Jan 2023', 'doctor': 'Dr. Sharma'},
    {'name': 'Type 2 Diabetes', 'status': 'Monitoring', 'diagnosed': 'Mar 2022', 'doctor': 'Dr. Gupta'},
    {'name': 'Hypertension', 'status': 'Active', 'diagnosed': 'Jun 2021', 'doctor': 'Dr. Mehra'},
  ];

  final _medications = [
    {'name': 'Metformin 500mg', 'freq': 'Twice daily · After Food', 'disease': 'Type 2 Diabetes'},
    {'name': 'Amlodipine 5mg', 'freq': 'Once daily · Morning', 'disease': 'Hypertension'},
    {'name': 'Aspirin 75mg', 'freq': 'Once daily · Bedtime', 'disease': 'Hypertension'},
  ];

  final _timelineEvents = [
    {'title': 'Metformin taken — 8:00 AM', 'time': 'Today 8:00', 'icon': 'med', 'color': AppColors.orange},
    {'title': 'QR scanned — Dr. Gupta', 'time': 'Today 3:15', 'icon': 'qr', 'color': AppColors.primary},
    {'title': 'Prescription uploaded — AI read', 'time': 'Yesterday', 'icon': 'doc', 'color': AppColors.teal},
    {'title': 'Hernia visit — Apollo Clinic', 'time': '2 days ago', 'icon': 'hosp', 'color': AppColors.statusActive},
    {'title': 'Son BCG vaccine — DONE ✓', 'time': '1 week ago', 'icon': 'vac', 'color': AppColors.green},
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  IconData _eventIcon(String type) {
    switch (type) {
      case 'med': return Icons.medication;
      case 'qr': return Icons.qr_code;
      case 'doc': return Icons.description;
      case 'hosp': return Icons.local_hospital;
      case 'vac': return Icons.vaccines;
      default: return Icons.circle;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgNavy,
      resizeToAvoidBottomInset: false,
      appBar: CustomAppBar(
        title: 'Ravi\'s Records',
        actions: [
          CustomIconButton(
            icon: Icons.add,
            onTap: () => _showAddDiseaseSheet(context),
            bgColor: AppColors.teal,
            iconColor: Colors.white,
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: Column(
        children: [
          // Tab bar
          Container(
            color: AppColors.bgDeepNavy,
            child: TabBar(
              controller: _tabController,
              indicatorColor: AppColors.teal,
              indicatorWeight: 3,
              labelColor: AppColors.accentTeal,
              unselectedLabelColor: AppColors.textMuted,
              labelStyle: AppTextStyles.captionBold,
              tabs: const [
                Tab(text: 'Diseases'),
                Tab(text: 'Medications'),
                Tab(text: 'Timeline'),
              ],
            ),
          ),

          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [
                // ── Diseases Tab ──────────────────────────────────────
                ListView(
                  padding: const EdgeInsets.all(16),
                  children: _diseases.map((d) {
                    return DiseaseCard(
                      name: d['name']!,
                      status: d['status']!,
                      diagnosed: d['diagnosed']!,
                      doctor: d['doctor']!,
                      onTap: (){
                        Get.to(DiseaseDetailScreen(diseaseName: d['name']!, status:d['status']!,));

                      },
                    );
                  }).toList(),
                ),

                // ── Medications Tab ───────────────────────────────────
                ListView(
                  padding: const EdgeInsets.all(16),
                  children: _medications.map((m) {
                    return McCard(
                      padding: const EdgeInsets.all(14),
                      child: Row(
                        children: [
                          Container(
                            width: 44,
                            height: 44,
                            decoration: BoxDecoration(
                              color: AppColors.teal.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: const Icon(Icons.medication, color: AppColors.teal, size: 22),
                          ),
                          const SizedBox(width: 14),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(m['name']!, style: AppTextStyles.bodyBold),
                                const SizedBox(height: 3),
                                Text(m['freq']!, style: AppTextStyles.caption),
                                const SizedBox(height: 2),
                                Text(
                                  m['disease']!,
                                  style: AppTextStyles.caption.copyWith(color: AppColors.accentTeal),
                                ),
                              ],
                            ),
                          ),
                          CustomIconButton(
                            icon: Icons.alarm,
                            onTap: () {
                              // Get.to(DiseaseDetailScreen(diseaseName: m['disease']!, status: m['freq']!,));
                            },
                            bgColor: AppColors.orange.withOpacity(0.15),
                            iconColor: AppColors.orange,
                            size: 36,
                          ),
                        ],
                      ),
                    );
                  }).toList()
                    ..add(  McCard(
                      padding: EdgeInsets.zero,
                      child: SizedBox(height: 80),
                    ),),
                ),

                // ── Timeline Tab ──────────────────────────────────────
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                      child: SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: ['All', 'Diseases', 'Meds', 'Vaccines', 'QR'].asMap().entries.map((e) {
                            return McFilterChip(
                              label: e.value,
                              isSelected: _timelineFilter == e.key,
                              onTap: () => setState(() => _timelineFilter = e.key),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    Expanded(
                      child: ListView.builder(
                        padding: const EdgeInsets.all(16),
                        itemCount: _timelineEvents.length,
                        itemBuilder: (_, i) {
                          final e = _timelineEvents[i];
                          return TimelineEventRow(
                            title: e['title'] as String,
                            time: e['time'] as String,
                            icon: _eventIcon(e['icon'] as String),
                            iconColor: e['color'] as Color,
                            isLast: i == _timelineEvents.length - 1,
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: CustomFab(onTap: () => _showAddDiseaseSheet(context)),
    );
  }

  void _showAddDiseaseSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCardNavy,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // neend aayi kya tuje ha
            Text('Add New', style: AppTextStyles.heading2),
            const SizedBox(height: 16),
            _SheetOption(icon: Icons.sick, label: 'Add Disease', color: AppColors.statusActive, onTap: () { Get.to(AddDiseaseScreen());}),
            const SizedBox(height: 10),
            _SheetOption(icon: Icons.medication, label: 'Add Medication', color: AppColors.teal, onTap: () { Get.to(AddMedicationScreen());}),
            const SizedBox(height: 10),
            _SheetOption(icon: Icons.camera_alt, label: 'Scan Prescription (AI)', color: AppColors.primary, onTap: () { Get.to(AiPrescriptionScreen());}),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

class _SheetOption extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _SheetOption({required this.icon, required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 22),
            const SizedBox(width: 14),
            Text(label, style: AppTextStyles.bodyBold),
          ],
        ),
      ),
    );
  }
}