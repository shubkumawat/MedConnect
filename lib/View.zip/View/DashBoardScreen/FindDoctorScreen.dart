import 'package:flutter/material.dart';

import 'package:digitalhealth/app/core//Util/AdditionalWidget/AdditionalWidget.dart';
import 'package:digitalhealth/app/core//Util/Colors/colors.dart';
import 'package:digitalhealth/app/core//Util/CustomButton/CustomButton.dart';
import 'package:digitalhealth/app/core//Util/CustomCardWidgets/CustomCardWidgets.dart';
import 'package:digitalhealth/app/core//Util/CustomTextField/CustomTextField.dart';
import 'package:digitalhealth/app/core//Util/Font/font_family.dart';

class FindScreen extends StatefulWidget {
  const FindScreen({super.key});
  @override
  State<FindScreen> createState() => _FindScreenState();
}

class _FindScreenState extends State<FindScreen> {
  int _selectedSpec = 0;
  final List<String> _specs = ['All', 'Cardiologist', 'Diabetologist', 'Surgeon', 'General'];

  final _doctors = [
    {'name': 'Dr. Sharma', 'spec': 'Cardiologist', 'hospital': 'Fortis Hospital', 'rating': '4.8', 'fee': '₹800'},
    {'name': 'Dr. Mehra', 'spec': 'Surgeon', 'hospital': 'Apollo Clinic', 'rating': '4.6', 'fee': '₹1,200'},
    {'name': 'Dr. Gupta', 'spec': 'Diabetologist', 'hospital': 'Max Hospital', 'rating': '4.9', 'fee': '₹600'},
    {'name': 'Dr. Anita Singh', 'spec': 'Cardiologist', 'hospital': 'AIIMS', 'rating': '4.7', 'fee': '₹500'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.bgNavy,
      resizeToAvoidBottomInset: false,
      appBar: const CustomAppBar(title: '🔍 Find Doctor'),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
            child: McSearchBar(hint: 'Search doctor, specialty, hospital...'),
          ),
          const SizedBox(height: 12),

          // Spec filter
          SizedBox(
            height: 36,
            child: ListView.builder(
              padding: const EdgeInsets.only(left: 16),
              scrollDirection: Axis.horizontal,
              itemCount: _specs.length,
              itemBuilder: (_, i) => McFilterChip(
                label: _specs[i],
                isSelected: _selectedSpec == i,
                activeColor: AppColors.orange,
                onTap: () => setState(() => _selectedSpec = i),
              ),
            ),
          ),
          const SizedBox(height: 16),

          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _doctors.length,
              itemBuilder: (_, i) {
                final d = _doctors[i];
                return GestureDetector(
                  onTap: () => _showDoctorProfile(context, d),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: AppColors.bgCardNavy,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Row(
                      children: [
                        Container(
                          width: 54,
                          height: 54,
                          decoration: const BoxDecoration(
                            color: AppColors.primary,
                            shape: BoxShape.circle,
                          ),
                          child: Center(
                            child: Text(
                              d['name']![4].toString(),
                              style: TextStyle(
                                // fontFamily: fontFamily,
                                fontSize: 20,
                                fontWeight: FontWeight.w600,
                                color: AppColors.textWhite,

                            ),
                          ),
                        )
                        ),
                        const SizedBox(width: 14),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(d['name']!, style: AppTextStyles.bodyBold),
                              Text('${d['spec']} · ${d['hospital']}', style: AppTextStyles.caption),
                              Text(d['fee']! + ' consultation', style: AppTextStyles.tealLabel),
                            ],
                          ),
                        ),
                        Column(
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.star, color: Color(0xFFFFC107), size: 14),
                                const SizedBox(width: 3),
                                Text(d['rating']!, style: AppTextStyles.captionBold),
                              ],
                            ),
                            const SizedBox(height: 6),
                            const Icon(Icons.chevron_right, color: AppColors.textMuted),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showDoctorProfile(BuildContext context, Map<String, String> d) {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.bgCardNavy,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (_) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.75,
        builder: (_, sc) => SingleChildScrollView(
          controller: sc,
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                // Handle
                Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.border,
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(height: 20),

                // Doctor header
                Container(
                  width: 80,
                  height: 80,
                  decoration: const BoxDecoration(
                    color: AppColors.teal,
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: Text(
                      d['name']![4].toString(),
                      style: TextStyle(color:AppColors.textWhite,fontSize: 32),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Text(d['name']!, style: AppTextStyles.heading2),
                Text('${d['spec']} · MD', style: AppTextStyles.body.copyWith(color: AppColors.accentTeal)),
                Text('${d['hospital']} · ${d['fee']}', style: AppTextStyles.caption),
                const SizedBox(height: 6),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.star, color: Color(0xFFFFC107), size: 18),
                    const SizedBox(width: 4),
                    Text(d['rating']!, style: AppTextStyles.bodyBold),
                    const SizedBox(width: 12),
                    Text('Mon–Sat: 10AM–5PM', style: AppTextStyles.caption),
                  ],
                ),
                const SizedBox(height: 20),

                // Buttons
                Row(
                  children: [
                    Expanded(
                      child: CustomPrimaryButton(text: '📞 Call', color: AppColors.green, onTap: () {}),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: CustomPrimaryButton(text: '⭐ Review', color: AppColors.orange, onTap: () {}),
                    ),
                  ],
                ),
                const SizedBox(height: 20),

                // Reviews
                SectionHeader(title: 'Patient Reviews'),
                const SizedBox(height: 12),
                _ReviewTile(name: 'Ravi K.', rating: 5, comment: 'Excellent doctor, very thorough.'),
                _ReviewTile(name: 'Priya K.', rating: 4, comment: 'Good service, short wait time.'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _ReviewTile extends StatelessWidget {
  final String name;
  final int rating;
  final String comment;

  const _ReviewTile({required this.name, required this.rating, required this.comment});

  @override
  Widget build(BuildContext context) {
    return McCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(name, style: AppTextStyles.bodyBold),
              const Spacer(),
              Row(
                children: List.generate(5, (i) => Icon(
                  i < rating ? Icons.star : Icons.star_border,
                  color: const Color(0xFFFFC107),
                  size: 14,
                )),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(comment, style: AppTextStyles.body),
        ],
      ),
    );
  }
}