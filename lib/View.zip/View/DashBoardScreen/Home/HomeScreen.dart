import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'package:digitalhealth/app/core/Util/AdditionalWidget/AdditionalWidget.dart';
import 'package:digitalhealth/app/core/Util/Colors/colors.dart';
import 'package:digitalhealth/app/core/Util/CustomButton/CustomButton.dart';
import 'package:digitalhealth/app/core/Util/CustomCardWidgets/CustomCardWidgets.dart';
import 'package:digitalhealth/app/core/Util/Font/font_family.dart';
import '../../../app/modules/home/views/video_series_screen.dart';
import '../QrScreen.dart';


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _activePatient = 0;
  int _selectedTopic = 0;

  final List<_Patient> _patients = [
    _Patient('RK', 'Self', AppColors.primary, 'Ravi Kumar', '34y · B+', '3 Diseases | 5 Meds | 12 Records'),
    _Patient('PK', 'Spouse', AppColors.teal, 'Priya Kumar', '31y · A+', '1 Disease | 2 Meds | 6 Records'),
    _Patient('AK', 'Son', AppColors.orange, 'Aryan Kumar', '8y · O+', '0 Diseases | 0 Meds | 3 Records'),
  ];

  final List<String> _topics = ['❤️ Heart', '🍎 Diabetes', '🧠 Mind', '🏃 Fitness'];

  @override
  Widget build(BuildContext context) {
    final patient = _patients[_activePatient];
    return Scaffold(
      backgroundColor: AppColors.bgNavy,
      resizeToAvoidBottomInset: false,
      appBar: CustomAppBar(
        title: 'Med Connect',
        actions: [
          CustomIconButton(
            icon: Icons.notifications_outlined,
            onTap: () {},
            bgColor: AppColors.appBarColor,
            iconColor: AppColors.textWhite,
          ),
          const SizedBox(width: 12),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 12),

            // ── Patient Switcher ──────────────────────────────────────
            McCard(
              padding: const EdgeInsets.all(14),
              color: AppColors.bgCardNavy,
              child: Column(
                children: [
                  Row(
                    children: List.generate(_patients.length, (i) {
                      return Padding(
                        padding: const EdgeInsets.only(right: 16),
                        child: GestureDetector(
                          onTap: () => setState(() => _activePatient = i),
                          child: PatientAvatar(
                            initials: _patients[i].initials,
                            color: _patients[i].color,
                            isActive: _activePatient == i,
                            size: 52,
                            label: _patients[i].relation,
                          ),
                        ),
                      );
                    })
                      ..add(
                        GestureDetector(
                          onTap: () {},
                          child: Column(
                            children: [
                              Container(
                                width: 52,
                                height: 52,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  border: Border.all(color: AppColors.border, width: 2),
                                  color: AppColors.bgCardNavy,
                                ),
                                child: const Icon(Icons.add, color: AppColors.textMuted),
                              ),
                              const SizedBox(height: 4),
                              Text('+', style: AppTextStyles.caption),
                            ],
                          ),
                        ),
                      ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 14),

            _buildVitalsCard(patient),
            const SizedBox(height: 20),

            // ── Reminders Strip ───────────────────────────────────────
            SectionHeader(title: 'Reminders', actionLabel: 'See all', onAction: () {}),
            const SizedBox(height: 12),
            _ReminderCard(
              title: 'Paracetamol',
              subtitle: 'Today, 10:00 AM',
              borderColor: AppColors.orange,
              trailing: const Icon(Icons.chevron_right, color: AppColors.textGray),
            ),
            const SizedBox(height: 12),
            _ReminderCard(
              title: 'Flu Shot',
              subtitle: 'Next Week',
              borderColor: AppColors.teal,
              trailing: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppColors.teal.withOpacity(0.25),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'PENDING',
                  style: TextStyle(
                    color: AppColors.green,
                    fontWeight: FontWeight.w700,
                    fontSize: 11,
                  ),
                ),
              ),
            ),


            const SizedBox(height: 20),

            // ── Quick Stats ───────────────────────────────────────────
            SectionHeader(title: 'Health Summary'),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    value: '3',
                    label: 'Diseases',
                    accentColor: AppColors.statusActive,
                    icon: Icons.sick,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: StatCard(
                    value: '5',
                    label: 'Medications',
                    accentColor: AppColors.teal,
                    icon: Icons.medication,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: StatCard(
                    value: '12',
                    label: 'Records',
                    accentColor: AppColors.primary,
                    icon: Icons.folder_outlined,
                  ),
                ),
              ],
            ),

            const SizedBox(height: 20),

            // ── Video Topics ──────────────────────────────────────────
            SectionHeader(title: 'Health Videos', actionLabel: 'See all', onAction: () {}),
            const SizedBox(height: 12),
            SizedBox(
              height: 36,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: _topics.length,
                itemBuilder: (_, i) => McFilterChip(
                  label: _topics[i],
                  isSelected: _selectedTopic == i,
                  activeColor: AppColors.orange,
                  onTap: () => setState(() => _selectedTopic = i),
                ),
              ),
            ),
            const SizedBox(height: 12),

            McCard(
              onTap: (){
                Get.to(VideoSeriesScreen());
              },
              child: Row(
                children: [
                  Container(
                    width: 60,
                    height: 60,
                    decoration: BoxDecoration(
                      color: AppColors.statusActive.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: const Icon(Icons.play_circle_fill, color: AppColors.statusActive, size: 32),
                  ),
                  const SizedBox(width: 14),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'How to Control Blood Pressure Naturally',
                          style: TextStyle(
                            color: AppColors.textTail,
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text('Dr. Anita Sharma · 3:24 · 2.1K views',
                            style: TextStyle(color: AppColors.textMuted, fontSize: 11)),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 100),
          ],
        ),
      ),
    );
  }
  // ── Big vitals + QR card ─────────────────────────────────────────────
  Widget _buildVitalsCard(_Patient patient) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: Column(
        children: [
          Container(
            width: double.infinity,
            color: AppColors.appBarColor,
            padding: const EdgeInsets.fromLTRB(22, 24, 22, 24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  patient.name == 'Ravi' ? 'Ravi Sharma' : patient.name,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                    fontSize: 22,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  patient.sub,
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.85),
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 20),
                Row(
                  children: const [
                    Expanded(
                      child: _VitalBox(icon: Icons.favorite_border, value: '72', label: 'BPM'),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _VitalBox(icon: Icons.air, value: '98%', label: 'SPO2'),
                    ),
                    SizedBox(width: 12),
                    Expanded(
                      child: _VitalBox(icon: Icons.monitor_heart_outlined, value: '120/80', label: 'BP'),
                    ),
                  ],
                ),
              ],
            ),
          ),
          //Divider(height: 1,color:Colors.black,),
          GestureDetector(
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const QrScreen())),
            child: Container(
              width: double.infinity,
              color: AppColors.tealDark,
              padding: const EdgeInsets.symmetric(vertical: 18),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.qr_code, color: Colors.white, size: 20),
                  SizedBox(width: 10),
                  Text(
                    'TAP TO GENERATE QR',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 14,
                      letterSpacing: 0.5,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
class _VitalBox extends StatelessWidget {
  final IconData icon;
  final String value;
  final String label;
  const _VitalBox({required this.icon, required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.white.withOpacity(0.15)),
      ),
      child: Column(
        children: [
          Icon(icon, color: AppColors.white, size: 22),
          const SizedBox(height: 8),
          Text(
            value,
            style: const TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w800,
              fontSize: 20,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            label,
            style: TextStyle(
              color: Colors.white.withOpacity(0.75),
              fontSize: 12,
            ),
          ),
        ],
      ),
    );
  }
}
class _ReminderCard extends StatelessWidget {
  final String title;
  final String subtitle;
  final Color borderColor;
  final Widget trailing;
  const _ReminderCard({
    required this.title,
    required this.subtitle,
    required this.borderColor,
    required this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.cardBg,
        borderRadius: BorderRadius.circular(14),
        border: Border(left: BorderSide(color: borderColor, width: 4),
            top: BorderSide(color: borderColor, width: 4)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.03),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: borderColor.withOpacity(0.15),
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    color: AppColors.textDark,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: const TextStyle(color: AppColors.textGray, fontSize: 13),
                ),
              ],
            ),
          ),
          trailing,
        ],
      ),
    );
  }
}
class _Patient {
  final String initials, relation, name, sub, stats;
  final Color color;
  const _Patient(this.initials, this.relation, this.color, this.name, this.sub, this.stats);
}